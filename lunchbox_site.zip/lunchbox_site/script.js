// Helpers: minimal cart with localStorage
const $ = (s, scope=document) => scope.querySelector(s);
const $$ = (s, scope=document) => Array.from(scope.querySelectorAll(s));

const CART_KEY = 'lunchbox_cart_v1';

const Cart = {
  get(){
    try { return JSON.parse(localStorage.getItem(CART_KEY)) || []; }
    catch(e){ return []; }
  },
  set(items){ localStorage.setItem(CART_KEY, JSON.stringify(items)); updateCartUI(); },
  add(item){
    const items = Cart.get();
    const existing = items.find(i => i.id === item.id);
    if(existing){ existing.qty += item.qty; }
    else { items.push(item); }
    Cart.set(items);
  },
  remove(id){
    const items = Cart.get().filter(i => i.id !== id);
    Cart.set(items);
  },
  total(){
    return Cart.get().reduce((t,i)=> t + i.price * i.qty, 0);
  },
  count(){
    return Cart.get().reduce((t,i)=> t + i.qty, 0);
  }
};

function money(v){ return '$' + v.toFixed(2); }

function updateYear(){ $('#year').textContent = new Date().getFullYear(); }

function updateCartUI(){
  $('#cartCount').textContent = Cart.count();

  const items = Cart.get();
  const wrap = $('#cartItems');
  wrap.innerHTML = '';
  items.forEach(i => {
    const el = document.createElement('div');
    el.className = 'cart-item';
    el.innerHTML = `
      <img src="${i.img}" alt="${i.name}">
      <div>
        <div><strong>${i.name}</strong></div>
        <div class="tiny">${i.qty} × ${money(i.price)}</div>
      </div>
      <button class="icon-btn" aria-label="Remove ${i.name}" data-remove="${i.id}">🗑</button>
    `;
    wrap.appendChild(el);
  });
  $('#cartTotal').textContent = money(Cart.total());
  $('.checkout').disabled = items.length === 0;
}

function setupCartDrawer(){
  const drawer = $('#cartDrawer');
  const open = $('#cartButton');
  const close = $('#closeCart');
  const backdrop = $('#cartBackdrop');

  const setOpen = (state) => {
    drawer.classList.toggle('open', state);
    drawer.setAttribute('aria-hidden', !state);
    if(state){ close.focus(); } else { open.focus(); }
  };

  open.addEventListener('click', ()=> setOpen(true));
  close.addEventListener('click', ()=> setOpen(false));
  backdrop.addEventListener('click', ()=> setOpen(false));

  $('#cartItems').addEventListener('click', (e)=>{
    const btn = e.target.closest('[data-remove]');
    if(btn){
      Cart.remove(btn.getAttribute('data-remove'));
    }
  });

  document.addEventListener('keydown', (e)=>{
    if(e.key === 'Escape'){ setOpen(false); }
  });
}

function setupAddButtons(){
  $$('.add').forEach(btn => {
    btn.addEventListener('click', ()=> {
      const id = btn.dataset.id;
      const name = btn.dataset.name;
      const price = parseFloat(btn.dataset.price);
      const img = btn.dataset.img;
      // quantity is sibling input within same product card
      const qtyInput = btn.closest('.product-info').querySelector('input[type="number"]');
      const qty = Math.max(1, parseInt(qtyInput.value || '1', 10));
      Cart.add({ id, name, price, img, qty });
      // animate cart bump
      const cc = $('#cartCount');
      cc.style.transform = 'scale(1.15)';
      setTimeout(()=> cc.style.transform = 'scale(1)', 150);
    });
  });
}

function setupInteractiveBars(){
  $$('.bar').forEach(bar => {
    bar.addEventListener('click', () => {
      const v = bar.dataset.value;
      alert(bar.parentElement.querySelector('.stat-label').textContent + ': ' + v + '%');
    });
  });
}

updateYear();
setupCartDrawer();
setupAddButtons();
setupInteractiveBars();
updateCartUI();
